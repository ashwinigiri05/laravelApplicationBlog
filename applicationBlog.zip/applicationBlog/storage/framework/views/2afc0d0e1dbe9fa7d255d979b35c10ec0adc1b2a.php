<?php /* /home/ashwinig/Documents/PHP_Training/curdblog/resources/views/tasks/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="col-sm-8 blog-main">
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('tasks.task', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
    <nav class="blog-pagination">
      <a href="#" class="btn btn-outline primary">Newer</a>
      <a href="#" class="btn btn-outline secondary disabled">Older</a>
    </nav>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
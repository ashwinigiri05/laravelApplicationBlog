<?php /* /home/ashwinig/Documents/PHP_Training/applicationBlog/resources/views/layouts/nav.blade.php */ ?>
<div class="navbar navbar-dark bg-dark">
  <div class="container">
      <nav class="blog-nav">
        <a class="blog-nav-item active" href="#"> Home</a>
      </nav>
  </div>
</div>
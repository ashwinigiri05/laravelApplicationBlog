<?php /* /home/ashwinig/Documents/PHP_Training/applicationBlog/resources/views/tasks/create.blade.php */ ?>
  <?php $__env->startSection('content'); ?>
    <div class="col-sm-8 blog-main">
      <h3><p class="text-primary">Create Blog</p></h3>
      <hr>

      <form method="POST" action = "/tasks">
          <?php echo e(csrf_field()); ?>


          <div class="form-group">
            <label for="title">Title:</label>
             <input type="text" class=" control<?php echo e($errors->has('title') ? 'is-danger' : ''); ?>" id="title" name="title" >
           </div>

          <div class="form-group"> 
            <label for="description ">Description :</label>
            <textarea name="description" id="description" class="control<?php echo e($errors->has('description') ? 'is-danger' : ''); ?>"></textarea>
          
        </div>
            
          <button type="submit" class="btn btn-info">Create</button>
        
      </form>
          
           <?php if($errors->any()): ?>
              <div class="notification is-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="text-danger"><?php echo e($error); ?></p>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                 
              </div>  
          <?php endif; ?>
   
       
     </div> 
   
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/ashwinig/Documents/PHP_Training/applicationBlog/resources/views/tasks/show.blade.php */ ?>
    <?php $__env->startSection('content'); ?>
        <div class="col-sm-8 blog-main">
            <h1 class="text-dark"><?php echo e($task->title); ?></h1>
            <p class="blog-post-meta text-info"><small><?php echo e($task->created_at->toFormattedDateString()); ?><small></p>
            <h3 class="text-secondary"><?php echo e($task->description); ?></h3> 
            <hr class="border-info"> 

        <div class="box">
                <div class="card-block">
                    <form method="POST" action = "/tasks/<?php echo e($task->id); ?>/details " class="box">
                        <?php echo e(csrf_field()); ?>

                            <div class="field">
                                <label for="name">Name:</label>
                                <input type="text" class="control<?php echo e($errors->has('name') ? 'is-danger' : ''); ?>"id="name" name="name">
                            </div>                  
                            <div class="field">
                                <label for="email">Email:</label>
                                <input type="text" class="control<?php echo e($errors->has('email') ? 'is-danger' : ''); ?>" id="email" name="email">
                            </div>
                            <div class="field">
                                <label for="comment">Comment:</label>
                                <textarea name="comment" id="comment" class="control<?php echo e($errors->has('comment') ? 'is-danger' : ''); ?>" ></textarea>
                            </div>
                            <hr class="border-info"> 
                            <button type="submit" class="btn btn-info">Add Comment</button>
                            <?php if($errors->any()): ?>
                            <div class="notification is-danger">
                              <ul>
                                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <p class="text-danger"><?php echo e($error); ?></p>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                               
                            </div>  
                        <?php endif; ?>
      
    
                    </form>        
                </div>
            </div>
            <hr class="border-info"> 
        <?php if($task->details->count()): ?>
            <div >
                    <style>
                            #customers {
                              font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                              border-collapse: collapse;
                              width: 100%;
                            }
                            
                            #customers td, #customers th {
                              border: 1px  #ddd;
                              padding: 8px;
                            }
                            
                            #customers tr:nth-child(even){background-color: #f2f2f2;}
                            
                            #customers tr:hover {background-color: #ddd;}
                            
                            #customers th {
                              padding-top: 12px;
                              padding-bottom: 12px;
                              text-align: left;
                              background-color:#666699;
                              color: white;
                            }
                            </style>
                <table id="customers">
                        <thead class="thead-light">
                       
                          <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Comment</th>
                            <th scope="col">email</th>
                          </tr>
                        </thead>
                        <tbody>
                         <?php $__currentLoopData = $task->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><strong><?php echo e($detail->name); ?></strong></td>
                            
                            <td><strong><?php echo e($detail->comment); ?> :</strong><small><?php echo e($detail->created_at->diffForHumans()); ?></small></td> 
                           
                            <td><strong><?php echo e($detail->email); ?></strong></td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                       
                       </table>
                
              
            </div>
        <?php endif; ?>
        
        
        
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>